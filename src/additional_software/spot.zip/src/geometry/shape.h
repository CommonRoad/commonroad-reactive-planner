/*
 * parent class for shapes
 */

#ifndef HEADER_SHAPES
#define HEADER_SHAPES

class shape
{
public:
	/*
	 * constructor
	 */
	shape()
	{

	}

	/*
	 * destructor
	 */
	virtual ~shape()
	{

	}

	/*
	 * setter functions
	 */

	/*
	* getter functions
	*/

private:

};




#endif
