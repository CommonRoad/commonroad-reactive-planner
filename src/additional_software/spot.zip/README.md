# README #

A tool for set-based prediction of traffic participants. The tool is implemented in C++.
